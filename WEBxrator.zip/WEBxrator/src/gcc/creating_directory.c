/*making directory and downloading files in chaned directory*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
char ch,*domain_name;
int count;
char link[500];
int secure;
char substr[500];
char split[1]="\n";
FILE *dm,*dir,*cnt;//dm(domain name)
void main()
{
	
	dm=fopen("./../temp/creating_directory/domain_c.txt","r+");
	dir=fopen("./../temp/creating_directory/cd_c.txt","w");
	cnt=fopen("./../temp/creating_directory/cd_back_c.txt","w");
	while((ch=getc(dm))!=EOF)
	{
		
		if(isprint(ch))
		{
			fseek(dm,-1,1);
			fscanf(dm,"%[^\n]",link);
			strcat(link,split);
			if(link[0]=='h'&&link[1]=='t'&&link[2]=='t'&&link[3]=='p')
			{
				if(link[4]=='s'&&link[5]==':'&&link[6]=='/'&&link[7]=='/')
				{
					secure=1;
				}
				else if(link[4]==':'&&link[5]=='/'&&link[6]=='/')
				{
					secure=0;
				}
				for(int i=0;i<500&&link[i]!='\n';i++)
				{
					substr[i]=link[i+7+secure];
				}
				fprintf(cnt,"./");
				for(int i=0;i<500&&substr[i]!='\n';i++)
				{
					if(substr[i]=='/')
					{
						fprintf(cnt,"../");//no of directory to come back after files is downloaded
					}
				}
				fprintf(cnt,"\n");
			}
			else
			{
				for(int i=0;i<500&&link[i]!='\n';i++)
				{
					substr[i]=link[i];//unnecessary,may help in debugging
				}
				fprintf(cnt,"./");
				for(int i=0;i<500&&substr[i]!='\n';i++)
				{
					if(substr[i]=='/')
					{
						fprintf(cnt,"../");//no of directory to come back after files is downloaded
					}
				}
				fprintf(cnt,"\n");
			}
			
			fprintf(dir,"%s",substr);
			
		}
		
	}	
	
}