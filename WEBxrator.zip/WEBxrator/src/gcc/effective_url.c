#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
char link[500],current;
void main()
{
	FILE *source,*intermediate;
	source=fopen("./../temp/link_correction/abs_corrected_c.txt","r");
	intermediate=fopen("./../temp/effective_url/intermediate.txt","w");
	while((current=getc(source))!=EOF)
	{
			fseek(source,-1,1);
			fscanf(source,"%[^\n]",link);
			fprintf(intermediate,"%s\n",link);
			system("./../shell/effective_url.sh");
	}
}
