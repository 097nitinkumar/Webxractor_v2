#!/bin/bash
line=$(cat ./../temp/effective_url/intermediate.txt)
URL=$line
echo $URL
curl -w "%{url_effective}\n" -I -L -s -S $URL -o /dev/null>./../temp/effective_url/temp_link
line=$(cat ./../temp/effective_url/temp_link)
echo $line>>./../temp/effective_url/destination.txt
cat ./../temp/effective_url/destination.txt>./../temp/download/download.txt