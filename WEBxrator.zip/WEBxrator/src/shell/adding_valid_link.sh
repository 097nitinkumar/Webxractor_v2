#!/bin/bash
cat ./../temp/download/download.txt>>./../../download.list
awk '!a[$0]++' ./../../download.list>./../../download_temp.list
cat ./../../download_temp.list>./../../download.list