/* program to convert relative links to absolute links*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int newline=1;
char ch,*domain_name;
char c[500];
void rel_to_abs()
{
	FILE *files,*parameter;
	files=fopen("./download.list","r");
	parameter=fopen("./parameter.link","w");
	char current;
	while((current=getc(files))!=EOF)
	{
			fseek(files,-1,1);
			fscanf(files,"%[^\n]",c);
    		fprintf(parameter,"%s\n",c);
    		system("./run.sh");
	}
}

void main()
{
	FILE *addvalue;
	char link[500];
	scanf("%[^\n]",link);
	addvalue=fopen("./download.list","w");
	fprintf(addvalue,"%s",link);
	fclose(addvalue);
	rel_to_abs();
}