#!/bin/bash
fname=$(cat ./parameter.link) #reading web url from file,does not includes new line
echo "Recieved line from ./parameter.link(run.sh):"
echo $fname
mkdir values -p 
mkdir values/temp -p #holds values to be deleted soon
mkdir values/final -p #holds final usefull data
#cd values

#working
get_file()
{
   	curl $fname >./values/file #storing accesed url in file name file
   	echo "extracted file from specifed url:"
   	cat ./values/file
   	echo "#########################################################################################################"
   	#no bug here is link is valid
}
get_links()
{	
	#extracting non repetetive links
	rm -f ./values/temp/links.log #removing existing file,necessary,recursive call to self
	grep -Po "(?<=href=')[^']*" ./values/file >> ./values/temp/links_t.log
	grep -Po '(?<=href=")[^"]*' ./values/file >> ./values/temp/links_t.log
	cat ./values/temp/links_t.log>./values/temp/selection_t
	cat ./values/final/list_f.log>>./values/temp/selection_t
	awk '!a[$0]++' ./values/temp/selection_t>./values/final/list_f.log #avoiding repetetion of links
	grep -Po '(?<=:url)[^)]*' ./values/file >>./values/final/link_css_t.log #output is (/images/nav_logo229.png	//bug detected
}
extract_relative_absolute()
{
	grep '^/.*' ./values/final/list_f.log>./src/temp/link_correction/relative_c.txt #for relative to absolute conersion
	grep "^[^/]" ./values/final/list_f.log >./src/temp/link_correction/abs_corrected_c.txt #corrected links from /relative_c.txt are stored here
	echo $fname >./src/temp/link_correction/domain_c.txt
	#grep "^[^/]" final/list_f.log >./../src/temp/input_c_abs.txt #for absolute to relative conversion
	grep '^/.*' ./values/final/list_f.log>>./values/raw/relative.log
	grep "^[^/]" ./values/final/list_f.log >>./values/raw/absolute.log
}
get_file
get_links
extract_relative_absolute
cd ./src/gcc/
./correcting_links.out
./effective_url.out
cd ./../shell/
./adding_valid_link.sh