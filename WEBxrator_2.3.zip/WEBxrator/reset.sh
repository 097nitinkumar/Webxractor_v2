#!/bin/bash
rm -f ./download.list
rm -f ./download_temp.list
rm -f ./output
rm -f ./parameter.link
touch ./download.list
touch ./download_temp.list
touch ./output
touch ./parameter.link

rm -f ./values/file
touch ./values/file


rm -f ./values/raw/absolute.log
rm -f ./values/raw/relative.log
touch ./values/raw/absolute.log
touch ./values/raw/relative.log

rm -f ./values/final/link_css_t.log
rm -f ./values/final/list_f.log
touch ./values/final/link_css_t.log
touch ./values/final/list_f.log

rm -f ./values/temp/links_t.log
rm -f ./values/temp/selection_t
touch ./values/temp/links_t.log
touch ./values/temp/selection_t

rm -f ./src/temp/creating_directory/cd_back_c.txt 
rm -f ./src/temp/creating_directory/cd_c.txt 
rm -f ./src/temp/creating_directory/domain_c.txt
touch ./src/temp/creating_directory/cd_back_c.txt
touch ./src/temp/creating_directory/cd_c.txt
touch ./src/temp/creating_directory/domain_c.txt

rm -f ./src/temp/download/download.txt
touch ./src/temp/download/download.txt

rm -f ./src/temp/effective_url/destination.txt
rm -f ./src/temp/effective_url/intermediate.txt
rm -f ./src/temp/effective_url/source.txt
rm -f ./src/temp/effective_url/temp_l
rm -f ./src/temp/effective_url/temp_link
touch ./src/temp/effective_url/destination.txt
touch ./src/temp/effective_url/intermediate.txt
touch ./src/temp/effective_url/source.txt
touch ./src/temp/effective_url/temp_l
touch ./src/temp/effective_url/temp_link

rm -f ./src/temp/link_correction/abs_corrected_c.txt
rm -f ./src/temp/link_correction/absolute_c.txt
rm -f ./src/temp/link_correction/domain_c.txt
rm -f ./src/temp/link_correction/lcount_c.txt
rm -f ./src/temp/link_correction/relative_c.txt
touch ./src/temp/link_correction/abs_corrected_c.txt
touch ./src/temp/link_correction/absolute_c.txt
touch ./src/temp/link_correction/domain_c.txt
touch ./src/temp/link_correction/lcount_c.txt
touch ./src/temp/link_correction/relative_c.txt

gcc ./src/gcc/correcting_links.c -o ./src/gcc/correcting_links.out
gcc ./src/gcc/effective_url.c -o ./src/gcc/effective_url..out
gcc ./main.c -o main.out