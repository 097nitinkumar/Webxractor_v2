/* program to convert relative links to absolute links*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char c[500];
int pos;
void rel_to_abs()
{
	FILE *files,*parameter;
	files=fopen("./download.list","r");//read mode
	char current;
	while((current=getc(files))!=EOF)
	{
			parameter=fopen("./parameter.link","w");
			fseek(files,-1,1);
			fscanf(files,"%[^\n]",c);//does not includes new line
			printf("Link read from ./download.list(main.c):%s",c);
			pos=ftell(files);//getting location of file pointer
    		fprintf(parameter,"%s",c);//does not includes new line
    		fclose(parameter);//closing files so they can be edited by shell
    		fclose(files);//closing files so they can be edited by shell
    		system("./run.sh");    		
    		files=fopen("./download.list","r");//reopening them when contents are added to them by shell
    		fseek(files,pos,0);//putting the pointer back to its place
    		if((current=getc(files))==EOF)
    		{
    			fseek(files,-1,1);//no need anyways
    			break;
    		}
    		else
    		{
    			fseek(files,-1,1);//moving a place back
    		}
	}
}

void main()
{
	FILE *addvalue;
	char link[500];
	scanf("%[^\n]",link);
	printf("Entered URl(main.c):%s\n",link);
	addvalue=fopen("./download.list","w");
	fprintf(addvalue,"%s",link);// new line not requires as shell will oprate from this input
	fclose(addvalue);
	system("./correcting_domain.sh"); //new line added by shell in download.list
	////no bug till here
	rel_to_abs();
}