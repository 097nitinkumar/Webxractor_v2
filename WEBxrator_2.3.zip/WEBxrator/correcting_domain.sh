#!/bin/bash
#bug tested
line=$(cat ./download.list)
#echo "Recieved line from ./download.list(correcting_domain.sh):"
#echo $line
URL=$line
curl -w "%{url_effective}\n" -I -L -s -S $URL -o /dev/null>./download.list
#issue is http and https url_effective doesnt reaches https links