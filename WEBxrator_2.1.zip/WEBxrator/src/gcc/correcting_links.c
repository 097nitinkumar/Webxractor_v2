/* program to convert relative links to absolute links*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int newline=1;
char ch,*domain_name;
int size;
long count;
char c[500];
char last;
int pos;
char split[1]="/";
char *weblink;//complete link
void read_domain()
{
	FILE *dm;//dm(domain name)
	dm=fopen("./../temp/link_correction/domain_c.txt","r+");
	fscanf(dm,"%[^\n]", c);
	pos=ftell(dm)/sizeof(char);
	//printf("%ld\n",ftell(dm));
	last=c[pos-1];
}
/*void read_line()
{
	FILE *lcn;//dm(domain name)
	char lc[15];
	lcn=fopen("./../temp/link_correction/lcount_c.txt","r");
	fscanf(lcn,"%s", lc);
	count = atoi(c);//giving result 0
}*/
void rel_to_abs()
{
	FILE *fi,*fo;
	fo=fopen("./../temp/link_correction/abs_corrected_c.txt","a");
	fi=fopen("./../temp/link_correction/relative_c.txt","r");
	int found=0,start=0;//start =0 is new line
	char rel_abs_link[100];//stores relative links
	char current;
	while((current=getc(fi))!=EOF)
	{
			
		if((current=='/')&&(!found)&&(!start))//checks if link in a new line is relative or not
		{
			fscanf(fi,"%[^\n]",rel_abs_link);
			//printf("%s\n",rel_abs_link ); //  /hello/ is read as hello/
			weblink = malloc(strlen(rel_abs_link)+strlen(c)+1);//+1 for the null-terminator
    		strcpy(weblink, c);
    		if(last=='/')//www.google.com/ hello
    		{
    			strcat(weblink,rel_abs_link);
    			//printf("%s %s\n",weblink,rel_abs_link );
    		}
    		else if(last!='/')//www.google.com hello
    		{
    			strcat(weblink,split);
    			strcat(weblink,rel_abs_link);
    		}
    		//printf("%c\n",last );
    		//printf("%s\n",weblink);
    		fprintf(fo,"%s\n",weblink);
    		found=0;
		}
		else if(current=='\n')//debug case
		{
			start=0;
    		//found=0;
		}
		else //absolute link
		{
			start=1;
			fscanf(fi,"%[^\n]",rel_abs_link);
			//fprintf(fo,"%s\n",weblink);
		}
	}
}

void main()
{
	read_domain();
	rel_to_abs();
	/*
	code to run effective url.out
	whose input will be from file abs_corrected_c.txt*/
}